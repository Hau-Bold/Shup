    Autor: Michael Krasser
    Shell und Prozesse SS 2019, IF8
    Blatt2: Prozesse unter Linux
    Aufgabe 23

    Vorbedingungen:
    Das aktuelle Arbeitsverzeichnis ist blatt2/a23

    Generierung:
    make
    (Makefile liegt im aktuellen Arbeitsverzeichnis)

    Bedienung:
    ./a23 um zu überprüfen, dassn Programm nicht durch strg + C abgebrochen werden kann
    ./a23& um zu überprüfen, dass Programm auf kill reagiert
    
