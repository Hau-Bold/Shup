    Autor: Michael Krasser
    Shell und Prozesse SS 2019, IF8
    Blatt2: Prozesse unter Linux
    Aufgabe 24

    Vorbedingungen:
    Das aktuelle Arbeitsverzeichnis ist blatt2/a24

    Generierung:
    make
    (Makefile liegt im aktuellen Arbeitsverzeichnis)

    Bedienung:
    ./a24 test/./test argumente
    (In test liegt ein ausfürbares Programm mit dem die Übergabe der Parameter überprüft werden kann) 
