    Autor: Michael Krasser
    Shell und Prozesse SS 2019, IF8
    Blatt2: Prozesse unter Linux
    Aufgabe 25

    Vorbedingungen:
    Das aktuelle Arbeitsverzeichnis ist blatt2/a25

    Generierung:
    make
    (Makefile liegt im aktuellen Arbeitsverzeichnis)

    Bedienung:
    ./a25
    Nach Start führt die Shell einen prompt in der Form
    user@host:cwd aus
    Nach dem Prompt wird eine User-Eingabe erwartet. Hier kann entweder ein Programm gestartet werden.(Angabe Pfad oder Name)
    Für Testzwecke ist in dem Ordner ein Ordner test enthalten,dort liegt ein ausführbarerer Programm welches Argumente entgegen nimmt und diese auf der Konsole ausgibt
   (auch hierfür liegt eine Makefile bereit)
    Mit dem Schlüsselwort "schluss" kann die Shell beendet werden.

   Hinweis: Überflüssige Fehlermeldungen können in constants.h durch Setzen des Flags VERBOSE=0 vermieden werden

