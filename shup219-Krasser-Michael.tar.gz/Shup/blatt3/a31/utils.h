#ifndef __UTILS_H__
#define __UTILS_H__

#include <stdlib.h>
//#include <time.h>

/*
 *dtermines the count of processes
 *
 **/
int getNextCountOfProcesses(void);

#endif
