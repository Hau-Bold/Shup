    Autor: Michael Krasser
    Shell und Prozesse SS 2019, IF8
    Blatt3: Synchronisation
    Aufgabe 23

    Vorbedingungen:
    Das aktuelle Arbeitsverzeichnis ist blatt3/a31

    Generierung:
    make
    (Makefile liegt im aktuellen Arbeitsverzeichnis)

    Bedienung:
    ./a31
    
